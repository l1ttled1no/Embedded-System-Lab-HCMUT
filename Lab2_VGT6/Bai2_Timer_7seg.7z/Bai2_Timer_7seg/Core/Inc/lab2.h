#ifndef LAB_2
#define LAB_2
#include "main.h"
#include "software_timer.h"
#include "led_7seg.h"

void init_exercise3(); 

void Exercise3();

void init_exercise4(); 

void Exercise4(); 

void init_exercise5(); 

void Exercise5(); 
#endif