#include "lab2.h"
#define SEGMENT_REFRESH_RATE_HZ 100
#define COLON_REFRESH_RATE_HZ 2
//#define SEGMENT_TIMER_MS 250 / SEGMENT_REFRESH_RATE_HZ // 4-digit: 1000ms/4 = 250ms
const uint16_t SEGMENT_TIMER_MS = 250 / SEGMENT_REFRESH_RATE_HZ;
const uint16_t COLON_TIMER_MS = 500 / COLON_REFRESH_RATE_HZ;

const uint16_t TIMER_CLOCK_MS_ = 1000;
void init_exercise3(){
    timerInit();
    // led_On(); 
    led7_init();
    led7_SetDigit(3, 0, 0); 
    led7_SetDigit(3, 1, 0); 
    led7_SetDigit(3, 2, 0); 
    led7_SetDigit(3, 3, 0); 
    setTimer1(SEGMENT_TIMER_MS);
}

void Exercise3(){
    if (timerFlag1 == 1) {
        led7_Scan(); 
        setTimer1(SEGMENT_TIMER_MS);
    }
}

uint8_t RT_Hour = 0;
uint8_t RT_Minute = 0;

void setClockTImer(){
	led7_SetDigit(RT_Hour / 10, 0, 0);
	led7_SetDigit(RT_Hour % 10, 1, 0);
	led7_SetDigit(RT_Minute / 10, 2, 0);
	led7_SetDigit(RT_Minute % 10, 3, 0);
}


void ClockCounter(){
	RT_Minute++;
	if (RT_Minute == 60) {
		RT_Hour++;
		RT_Minute = 0;
	}
	if (RT_Hour == 24){
		RT_Hour = 0;
	}
	setClockTImer();
}

void init_exercise4(){
    timerInit();
    // led_On(); 
    led7_init();
	setTimer1(SEGMENT_TIMER_MS); // Segment Timer
	setTimer2(COLON_TIMER_MS);
	setTimer3(TIMER_CLOCK_MS_); // Clock Counter
}

uint8_t colonState = 0;


void Exercise4(){
	if (timerFlag1 == 1){
		led7_Scan();
		setTimer1(SEGMENT_TIMER_MS);
	}
	if (timerFlag2 == 1){
		led7_SetColon(colonState);
		colonState = 1 - colonState;
		setTimer2(COLON_TIMER_MS);
	}
	if (timerFlag3 == 1){
		ClockCounter();
		setTimer3(TIMER_CLOCK_MS_);
	}
}


void init_exercise5(){
	timerInit();
	 // led_On();
	led7_init();
	setTimer1(SEGMENT_TIMER_MS); // Segment Timer
	setTimer2(1000);
}

uint8_t buffer[4] = {3, 4, 5, 6};
uint8_t temp_buffer = 0;
void arrayShifting(){

	temp_buffer = buffer[3];
	buffer[3] = buffer[2];
	buffer[2] = buffer[1];
	buffer[1] = buffer[0];
	buffer[0] = temp_buffer;

	for (int i = 0; i < 4; ++i){
		led7_SetDigit(buffer[i], i, 0);
	}
}

void Exercise5(){
	if (timerFlag1 == 1){
		led7_Scan();
		setTimer1(SEGMENT_TIMER_MS);
	}
	if (timerFlag2 == 1){
		arrayShifting();
		setTimer2(1000);
	}
}


